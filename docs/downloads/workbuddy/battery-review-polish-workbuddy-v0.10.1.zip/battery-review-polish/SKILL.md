---
name: battery-review-polish
description: Polish, translate, or compress existing battery Review prose while preserving evidence, numbers, citations, technical terms, and claim strength. Not for new arguments.
description_zh: "润色现有综述段落，保留原始科学含义和引文。"
description_en: "Polish, translate, or compress existing battery Review prose while preserving evidence, numbers, citations, technical terms, and claim strength. Not for new arguments."
version: 0.10.1
author: "郭硕、姜金龙｜上海理工大学能源材料科学研究院"
---

# Battery Review prose polish

<!-- execution-contract -->
For model/tool adaptation or resuming a task, read [the execution guide](references/EXECUTION.md). DeepSeek Flash uses short stages and checkpoints; DeepSeek Pro can plan larger text/evidence batches, with the same scientific checks. Reply in the user's language with the result, usable result/preview links and material unresolved questions. Keep mappings, configuration, logs and recovery records inside the project's `.voltpeer/` folder; do not link them in a normal final reply. Provide the corresponding source record only when the user explicitly requests provenance. Use only capabilities actually available in the current model and host.
<!-- /execution-contract -->

Use this for language, flow, translation, concision, or journal-style adjustment of existing Review text. Preserve the author's intended argument and section structure unless the user asks for a substantive rewrite. When a paragraph lacks evidence, mark the gap; do not hide it with smoother prose.

## Preserve scientific meaning

Keep every value, unit, denominator, battery configuration, tested branch, cycle baseline, condition, source, citation key, and uncertainty attached to the same claim. Do not change `may`, `suggests`, or `is consistent with` into causal certainty. Keep material-level, electrode-level, cell-level, and system-level language distinct. Respect the manuscript's glossary for cathode/anode, lithiation/delithiation, sodiation/desodiation, efficiency, retention, and energy boundary.

If a phrase is ambiguous, propose a precise alternative and flag the decision. If the source is not available, do not assert that a scientific correction is verified. For translation, maintain technical meaning and citation positions while using natural prose in the target language. Avoid repeated template openings, empty claims of novelty, and inflated adjectives. Retain productive caveats and counterevidence.

## Deliverable

Return the revised text in the requested format plus a concise note of any substantive ambiguities or unsupported statements found. For a file edit, show a diff or change summary. If the requested word reduction would delete an essential limitation, explain the tradeoff and offer a shorter supported version. Use `battery-review-write` when the task requires a new section or a change to the article's argument.
