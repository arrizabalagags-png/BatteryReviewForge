"""Inspect or plot author-supplied CSV/TSV/TXT/XLSX battery data."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from batteryplot import (
    DataContractError, coulombic_efficiency, cycling_capacity, cycle_retention,
    nyquist, rate_capability, save_bundle, symmetric_voltage, voltage_capacity,
    tofsims_map, tofsims_depth,
)
from batteryplot.ingest import PLOT_COLUMNS, apply_mapping, inspect_table, read_table
from batteryplot.style import PRESETS, register_community_style


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("styles", help="List named palette/style choices before plotting")
    inspect_cmd = sub.add_parser("inspect", help="Show sheets/columns and candidate plot families")
    inspect_cmd.add_argument("--data", type=Path, required=True)
    inspect_cmd.add_argument("--sheet")
    plot_cmd = sub.add_parser("plot", help="Render an author-reviewed mapping")
    plot_cmd.add_argument("--data", type=Path, required=True)
    plot_cmd.add_argument("--metadata", type=Path, required=True)
    plot_cmd.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "styles":
            print(json.dumps({name: {key: preset[key] for key in ("label_zh", "label_en", "purpose", "swatches")}
                              for name, preset in PRESETS.items()}, ensure_ascii=False, indent=2))
            return
        if args.command == "inspect":
            rows = read_table(args.data, sheet=args.sheet)
            print(json.dumps(inspect_table(rows), ensure_ascii=False, indent=2))
            return
        config = json.loads(args.metadata.read_text(encoding="utf-8"))
        kind = config.get("kind")
        style = config.get("style")
        if not style:
            raise DataContractError("Missing style; ask the author to choose one shown by 'styles' and record it in metadata")
        community_provenance = None
        if style.startswith("community:"):
            if not config.get("community_style_lock"):
                raise DataContractError("Community style requires an explicitly selected local lock file")
            pin, community_provenance = register_community_style(config["community_style_lock"])
            if pin != style:
                raise DataContractError("Style name and community lock select different versions")
        if style not in PRESETS:
            raise DataContractError(f"Unknown style {style!r}; choose one of {', '.join(PRESETS)}")
        if kind not in PLOT_COLUMNS:
            raise DataContractError(f"Unknown plot kind {kind!r}; choose one of {', '.join(PLOT_COLUMNS)}")
        rows = apply_mapping(read_table(args.data, sheet=config.get("sheet")),
                             config.get("columns", {}), config.get("common", {}))
        if not any(set(option) <= set(rows[0]) for option in PLOT_COLUMNS[kind]):
            raise DataContractError(f"Mapped table lacks core columns for {kind}")
        options = {key: config[key] for key in ("mode", "condition_note", "width_mm", "height_mm", "style") if key in config}
        if kind in {"tofsims_map", "tofsims_depth"}:
            if "sample_id" not in config or (kind == "tofsims_map" and "fragment" not in config):
                raise DataContractError("ToF-SIMS metadata needs sample_id and map plots also need fragment")
            tof_options = {key: config[key] for key in ("width_mm", "height_mm", "style") if key in config}
            if kind == "tofsims_map":
                fig, _ = tofsims_map(rows, sample_id=config["sample_id"], fragment=config["fragment"], **tof_options)
            else:
                fig, _ = tofsims_depth(rows, sample_id=config["sample_id"], **tof_options)
        elif kind in {"full_cell_cycling", "half_cell_cycling"}:
            fig, _ = cycling_capacity(rows, cell_configuration=kind.split("_")[0], **options)
        elif kind == "coulombic_efficiency":
            fig, _ = coulombic_efficiency(rows, **options)
        elif kind == "symmetric_cell_voltage":
            fig, _ = symmetric_voltage(rows, **options)
        elif kind == "voltage_capacity":
            fig, _ = voltage_capacity(rows, **options)
        elif kind == "nyquist":
            fig, _ = nyquist(rows, **options)
        elif kind == "cycle_retention":
            fig, _ = cycle_retention(rows, **options)
        else:
            fig, _ = rate_capability(rows, **options)
        fig.batteryplot_meta["source_sha256"] = hashlib.sha256(args.data.read_bytes()).hexdigest()
        if community_provenance:
            fig.batteryplot_meta["community_style"] = community_provenance
        files = save_bundle(fig, args.out, claim=config["claim"], source_data=str(args.data),
                            caption_notes=config["caption_notes"], close=True)
        print(json.dumps({"kind": kind, "files": [str(path) for path in files]}, ensure_ascii=False, indent=2))
    except (DataContractError, KeyError, json.JSONDecodeError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
