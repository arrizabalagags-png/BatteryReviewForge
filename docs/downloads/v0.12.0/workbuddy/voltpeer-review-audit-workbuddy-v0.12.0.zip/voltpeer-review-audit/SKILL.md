---
name: voltpeer-review-audit
description: Audit a near-complete battery Review or Perspective before submission for scope, evidence, metrics, figures, and consistency. Use for a preflight findings list, not copyediting or rebuttal.
description_zh: "投稿前检查整篇电池综述的论点、证据、图表与一致性。"
description_en: "Audit a near-complete battery Review or Perspective before submission for scope, evidence, metrics, figures, and consistency. Use for a preflight findings list, not copyediting or rebuttal."
version: 0.12.0
author: "郭硕、姜金龙｜上海理工大学能源材料科学研究院"
---

# Whole-manuscript battery Review audit

<!-- execution-contract -->
For model/tool adaptation or resuming a task, read [the execution guide](references/EXECUTION.md). DeepSeek Flash uses short stages and checkpoints; DeepSeek Pro can plan larger text/evidence batches, with the same scientific checks. Reply in the user's language with the result, usable result/preview links and material unresolved questions. Keep mappings, configuration, logs and recovery records inside the project's `.voltpeer/` folder; do not link them in a normal final reply. Provide the corresponding source record only when the user explicitly requests provenance. Use only capabilities actually available in the current model and host.
<!-- /execution-contract -->

Use this when the user asks whether a draft is scientifically and structurally ready. Identify the manuscript version, current project brief, source access, target venue if any, and requested depth. An audit is a check of the supplied artifact, not an independent referee persona or a language-only edit.

## Inspect in decision order

1. **Identity and contribution:** compare title, abstract, central judgement, section sequence, display items, and conclusion with the current brief and close competing Reviews. Flag scope drift and claims of “first” without proof.
2. **Evidence:** sample or fully check consequential numeric, mechanism, safety, cost, scale-up, priority, and negative claims against original sources according to the task. Distinguish source not obtained (`NV`) from source checked but field unreported (`NR`). Identify unsupported paragraph-end citation clusters and missing counterevidence.
3. **Battery comparability:** inspect tables and graphics for cell type, package, branch/cycle, denominator, loading, electrolyte, N/P or other inventory, operating conditions, uncertainty, and reported versus modelled status. Do not accept unconditional ranking of incomparable results.
4. **Display integrity:** compare every figure/table assertion to caption and source, then inspect final-size legibility, effective resolution, and reuse permissions. A correct credit line is not a permission document.
5. **Consistency and package:** check terminology, figure/table numbering, cross-references, bibliography, declarations, and venue-specific constraints when known. Obtain current official journal rules for the exact article type through `voltpeer-submission` when that is part of the request.

Report findings by severity with exact manuscript location, why each matters, evidence checked, proposed correction, and whether it blocks submission. Separate `verified`, `not checked`, and `author decision` items. An attractive draft with unresolved central evidence or missing rights is not ready; a draft with only minor prose issues may be. Do not claim all citations were checked if the audit sampled them, and do not silently rewrite the authors' scientific position.
