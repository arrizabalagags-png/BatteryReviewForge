---
name: voltpeer-response
description: Draft and verify point-by-point responses to editor and reviewer comments on a battery Review, with traceable manuscript revisions.
description_zh: "逐条整理审稿意见、修改内容与回复。"
description_en: "Draft and verify point-by-point responses to editor and reviewer comments on a battery Review, with traceable manuscript revisions."
version: 0.12.0
author: "郭硕、姜金龙｜上海理工大学能源材料科学研究院"
---

# Reviewer response and resubmission

<!-- execution-contract -->
For model/tool adaptation or resuming a task, read [the execution guide](references/EXECUTION.md). DeepSeek Flash uses short stages and checkpoints; DeepSeek Pro can plan larger text/evidence batches, with the same scientific checks. Reply in the user's language with the result, usable result/preview links and material unresolved questions. Keep mappings, configuration, logs and recovery records inside the project's `.voltpeer/` folder; do not link them in a normal final reply. Provide the corresponding source record only when the user explicitly requests provenance. Use only capabilities actually available in the current model and host.
<!-- /execution-contract -->

Use this for received peer-review comments or manuscript revision after review. Use [RESPONSE_MATRIX.md](assets/templates/RESPONSE_MATRIX.md) only if the project lacks a better format. For a new independent referee report, use `voltpeer-reviewer` and keep it separate from response drafting.

## Received reviews: point-by-point map

For every editor and reviewer point, record its exact request, the underlying issue, decision (`accept`, `partially accept`, `rebut with evidence`, `needs author decision`), action, manuscript location, supporting source/data, and response text. Keep the editor's instructions separate from reviewer suggestions. Group duplicate issues only after each numbered point retains an explicit answer.

Before writing a rebuttal, verify the proposed scientific correction. For a battery-performance dispute, recheck cell type, branch, denominator, loading, electrolyte, N/P, cycling baseline, temperature, and whether a figure mixes measured and modelled values. If the evidence remains thin, narrow the claim and say so. Do not invent a new experiment, permission, source, or author approval.

## Revision consistency gate

Apply approved changes to the actual manuscript and relevant figures/tables, then compare every response claim with the revised location. A response saying “we revised Section 3” is incomplete if Section 3 still carries the old statement. Check that changes to the abstract, conclusion, visual summary, and cover letter reflect substantive revisions. Keep a versioned record of changes, unresolved points, and author decisions.

The final report should say whether the comments were responded to and what remains open. Say “re-reviewed” only if a separate review of the revised version was actually performed. Confidential reviewer materials stay in the user's project, not in a public skill repository.
