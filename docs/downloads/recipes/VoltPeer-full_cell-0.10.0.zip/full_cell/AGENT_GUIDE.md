# 给助手的接手说明

此包的resource_id与网站样图一致，独立源码、依赖和演示输入均已包含。先读input_contract.json和用户真实输入，不需要加载其他整套图库。只使用能读本地文件、运行Python并保存结果的Agent。

1. 在用户研究项目中解压或复制整个包。保留原文件，不修改全局安装Skill。
2. 在项目独立venv安装requirements.txt。先用config.demo.json验证运行环境；这是原创合成演示。
3. 复制config.real.example.json到新文件，核对列映射、每个样品、单位、归一化分母及测试条件。所有null需由作者资料确认，不把演示温度、体系、倍率、辐射、测试面积或SOC定义复制给真实数据。
4. 优先只改配置和显示名；格式不同再增加小CSV适配器，另存规范化数据与映射记录；确实超出契约才改项目副本src/renderer.py，记录差异并重检。
5. `python src/plot.py --config <已确认配置> --out <Working结果>`。真实缺文件、单位、面积/质量基准、工况或XRD同步时先停；不得随机生成或调用demo/generate_data.py作为真实输入后备。
6. `python checks.py --working <Working结果>`核对文件哈希和实际绘图数组记录。技术通过不等于科学审查完成。先看index.html预览，再核对原值、标签、测试条件、图例、PDF和期刊最新要求。

只交给用户结果链接和影响使用的缺口。QA/来源/状态保存在Working/.voltpeer，不能省掉或冒充已完成科学审查。Flash可读图片时做最终视觉核对；当前Pro无视觉时保留人工/具备视觉工具的检查项，不谎称看过图。

样式可继承；数据、条件与结论不能继承。既有坐标/色标范围会裁掉新值时程序停止，请用auto或经作者确认扩大范围。signed voltage不能取绝对值；XRD不得按CSV行顺序reshape，不拟合物相、不插值、不补测量点。可选CE只能读实际记录，不凭容量列猜。

重复运行会新建带版本的Working目录。对外分享需作者确认权利、许可、姓名/课题/未公开图像；不要上传整个Working。包内src/share_bundle.py可按现有交付契约创建脱敏Share包，自动检查不代替人工审查。
