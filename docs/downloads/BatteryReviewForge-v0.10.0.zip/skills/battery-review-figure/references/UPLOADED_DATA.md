# 把电池数据文件变成图

给 Codex 原始或整理好的 CSV、TSV、TXT、XLSX 文件，并说清“这是什么电芯、想画什么、图给谁看”。不用自己写 Matplotlib，也不用手写下面的 JSON；Codex 会查列名并生成映射记录。缺条件时先指出缺什么；不能从文件名猜成论文结论。

## 最短路径

在仓库根目录安装一次依赖：

```bash
python -m pip install -r requirements.txt
```

先看文件里有哪些列：

```bash
python scripts/plot_uploaded.py inspect --data my_data.xlsx --sheet Sheet1
```

若工作簿只有一张表，可省略 `--sheet`。脚本显示列名、前三行和可能的图型；候选只说明列形状相符，不代表数据、单位或实验条件正确。准备一份 JSON 映射后再画：

画最终图前，看[六种风格预览](STYLE_PRESETS.md)并让作者选一套；如果整篇稿件已选过，就沿用。命令行也可列出风格：`python scripts/plot_uploaded.py styles`。没有选择时继续查列和条件，绘图命令会明确报错而不会猜默认风格。

```bash
python scripts/plot_uploaded.py plot --data my_data.xlsx --metadata my_figure.json --out figures/Fig2a
```

输出 PDF、SVG、300 dpi PNG 和 `.provenance.json`。CSV、TSV、TXT 同样可用。旧版 XLS、Origin 工程、各品牌仪器专有格式须先导出可读表；不要假装已解析其内部结构。

## 映射文件示例：库伦效率

这份示例只说明字段写法，`source_id`、`evidence_state` 和条件必须来自真实文件与作者核查。

```json
{
  "kind": "coulombic_efficiency",
  "style": "rose_blue",
  "claim": "A 与 B 的库伦效率变化",
  "caption_notes": "说明电芯、分子/分母、测试倍率、温度、圈数和异常点。",
  "columns": {
    "series": "Sample",
    "cycle": "Cycle Index",
    "ce_pct": "CE (%)"
  },
  "common": {
    "source_id": "local:experiment-2026-001",
    "evidence_state": "verified",
    "chemistry": "Li metal",
    "cell_configuration": "half cell",
    "ce_definition": "stripped capacity / plated capacity",
    "rate": "1 mA cm-2",
    "temperature_c": "25",
    "loading_mg_cm2": "2",
    "electrolyte_ul_mg": "10",
    "voltage_window_v": "0-1"
  }
}
```

`columns` 的左边是绘图工具的标准字段，右边是作者文件里的列名。`common` 给所有行补相同实验信息；若样品条件不同，请把条件放到数据行，不要用同一个值盖过去。CSV 表中已有标准列时，`columns` 可留空。所有数字行都须有可追溯的 `source_id` 和作者已核的 `evidence_state=verified`。文件上传本身不等于核实。

如果没有现成的 `ce_pct`，把两列映射为 `ce_numerator` 与 `ce_denominator`；脚本按 `100 × 分子 / 分母` 计算。必须写 `ce_definition`，比如金属沉积/剥离实验的“剥离容量 / 沉积容量”，或某个全电池测试定义的“放电容量 / 充电容量”。不要把两者混用。CE 高于 100% 的点不会被自动压成 100%，需回查源数据和定义。

## 选图与必须说明的条件

| 想展示什么 | `kind` | 最少数据列 | 不可省略的说明 |
| --- | --- | --- | --- |
| 库伦效率 | `coulombic_efficiency` | `series, cycle, ce_pct`，或分子/分母两列 | CE 定义、电芯、倍率/电流密度、温度、容量基准 |
| 全电池循环容量 | `full_cell_cycling` | `series, cycle, discharge_capacity` | 正负极、容量分母、N/P、载量、液量、电压范围、倍率 |
| 半电池循环容量 | `half_cell_cycling` | 同上 | 工作电极与对/参比金属、容量分母、载量、电压范围 |
| 对称电池电压 | `symmetric_cell_voltage` | `series, time_h, voltage_mv` | 两侧电极、正负极性、电流密度、每半周期面积容量、外加压力（若相关）、失效判据 |
| 充放电曲线 | `voltage_capacity` | `series, cycle, direction, capacity, voltage_v` | `charge/discharge` 方向、选取圈数、容量分母、电压范围 |
| EIS Nyquist | `nyquist` | `series, z_real_ohm, minus_z_imag_ohm` | 频率范围、SOC/循环状态、扰动幅值和拟合方式（如有） |
| 循环保持率 | `cycle_retention` | `series, cycle, retention_pct, reference_cycle` | 明确写出作为 100% 的参考圈；没有就先画原始容量，不能擅自算保持率 |
| 倍率性能 | `rate_capability` | `series, step, rate_label, capacity` | 实际测试顺序、恢复步骤、容量单位与分母 |
| ToF-SIMS 离子图 | `tofsims_map` | `sample_id, fragment, x_um, y_um, signal` | 像素坐标必须来自仪器标定；选择一个样品及碎片；提供离子极性、取样状态、信号单位、归一化方式 |
| ToF-SIMS 深度曲线 | `tofsims_depth` | `sample_id, fragment, sputter_time_s, signal` | 同一组碎片须有相同时间网格；横轴保持溅射时间，除非有独立坑深校准 |

标准字段的详细条件见 [绘图库说明](PYTHON_PLOTTING.md)。一个样品的原始曲线可以先做核查草图；要把多个样品画在同一坐标里做直接比较，还要让相关测试条件相同。多条样品曲线或跨不同 `source_id` 时，图型列出的相关条件即使在每份材料中都未填写，也不能当成“相同”；直接比较会被拦下。条件不同或信息不足时，可用 `mode: "contextual"` 加明确的 `condition_note` 展示背景，但不能据此给不同电芯直接排优劣。

仪器导出的多行表头、混合单位或带公式但无缓存值的工作簿，需要先另存为“第一行是唯一列名、每行一个观测”的表格；保留原始文件和转换说明。脚本不会悄悄跳过表头或把空格当零。

## ToF-SIMS 文件怎么交

导出 CSV/XLSX 后先用 `inspect` 看列。二维成像数据一行一个像素，提供 `x_um, y_um, signal, fragment, sample_id`；深度曲线一行一个时间点和碎片，提供 `sputter_time_s, signal, fragment, sample_id`。两者都需要 `source_id, evidence_state=verified, signal_unit, normalization, ion_polarity, measurement_state`，可放在表格列，也可把每行相同的值写在映射 JSON 的 `common` 中。`x_um/y_um` 应来自仪器或作者的像素尺度标定；不接受按图片宽度猜微米。映射 JSON 还需显式写 `kind`、`style`、`sample_id`；离子图另需 `fragment`。输出仍是 PDF/SVG/PNG 和来源记录。

画廊里的 [ToF-SIMS 样图](https://github.com/arrizabalagags-png/BatteryReviewForge/blob/79b4238a5a7dfc963bafc0aefacd2337f9795ba8/docs/assets/gallery/tofsims-demo.png) 是**完全虚构的数学示例**。其中的色斑不代表显微观察，曲线也不代表某种电解液；其 CSV 在画廊 `data/` 内。真实数据中不要把不同碎片的相对信号直接写成组分百分比，也不要把溅射秒数改标纳米而没有单独测得的坑深标定。[电池界面 ToF-SIMS 方法研究](https://www.nature.com/articles/s42004-025-01426-0) 讨论了溅射引起的形貌和层混合问题；[正极界面的成像与深度剖析实例](https://www.nature.com/articles/ncomms14589) 展示了化学图与时间剖面的互补用途。

## 交图前 30 秒检查

打开最终尺寸的 PNG 和矢量 PDF：单位是否在轴上、横轴是否按原始顺序、异常点是否保留、图例是否挡住曲线、线与字是否可读。库伦效率的放大纵轴必须明显显示刻度；对称电池保留正负电压与失败段；电压–容量图保留充放电方向和圈数。再看 `.provenance.json` 的来源文件、哈希、图型和计算说明。图要拼在一起时交给 `battery-figure-assemble`。

## When this is used in English

Run `inspect` on the uploaded table, map source columns and scientific metadata in JSON, then run `plot`. The file extension determines how to read the table; the data columns and declared cell/test conditions determine the chart. No private reference assets or paper data are bundled.
Ask once for a named style before final plotting, or reuse the manuscript's recorded choice. `plot` requires `style` in the mapping JSON; use the `styles` command or [preview](STYLE_PRESETS.md) to see options.
