SYNTHETIC DEMONSTRATION / 虚构演示，非实验结果
Run: python render.py --data-root data --output-dir output
Requires Arial installed; missing fonts raise an error rather than silently changing type.
All CSVs are unchanged copies of the existing BRF synthetic examples. Never use them as experimental evidence.
Panel sources, display offsets, font checks and millimetre frames are recorded in each metadata.json.
The original source metadata beside each CSV defines its simulated conditions.
结构与光谱包含三个独立演示；日常电化学包含循环和倍率两组；组合图是虚构 A/B 对照。
