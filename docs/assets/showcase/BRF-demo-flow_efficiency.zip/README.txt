Open flow_efficiency/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
