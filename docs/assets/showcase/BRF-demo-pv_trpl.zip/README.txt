Open pv_trpl/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
