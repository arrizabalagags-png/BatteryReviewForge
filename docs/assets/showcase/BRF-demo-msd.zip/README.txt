BatteryReviewForge 示例：msd
这是虚构演示数据，不是实验结果。
请先阅读 msd/metadata.json 的 source_files、单位、条件和图型。
全部输入保留相对路径；不要移动或改名其中单个 CSV。
让 AI 软件核对文件后绘图；输出到新建 brf-output，保留原始输入。
