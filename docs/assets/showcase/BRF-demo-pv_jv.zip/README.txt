Open pv_jv/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
