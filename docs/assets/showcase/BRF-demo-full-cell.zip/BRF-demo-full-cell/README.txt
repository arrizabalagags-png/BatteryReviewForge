These files are synthetic demonstration data, not experimental results.
Give both CSV files to BatteryReviewForge. Check columns, units and cell conditions before plotting.
