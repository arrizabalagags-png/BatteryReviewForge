VoltPeer 示例：ionic_conductivity

包含样图、示例数据和 Python 源码。数据由声明的教学模型生成，不是实验结果。
先看 ionic_conductivity/metadata.json 中的列名、单位、测试条件和模型说明。

重画示例（无需 AI，也不调用模型）：
  python -m venv .venv
  Windows: .venv\Scripts\python -m pip install -r requirements.txt
  Windows: .venv\Scripts\python render_existing.py --output brf-output
  macOS/Linux: .venv/bin/python -m pip install -r requirements.txt
  macOS/Linux: .venv/bin/python render_existing.py --output brf-output

已备好 numpy 和 matplotlib 的环境可直接运行最后一条命令。
结果在 brf-output：PNG、SVG、PDF、本次输入副本和运行记录。目录已存在时会停止，请换一个名称。

换成自己的数据：保留整个文件夹和相对路径，让 AI 对照样图与 code/ 源码核对列名、单位、测试条件和坐标范围，再替换 CSV。
这是同类型图的源码起点，不会自动识别任意仪器表头。换过的输入只记为待核对的作者数据，不沿用示例的科学背书。
有意调整 code/ 中的源码后，运行命令加 --allow-code-changes；改后的文件哈希会单独记录，缺文件仍会停止。
你也可以用自己的话说：照这张图，用我的数据画；先问清楚缺的条件，原文件不要改。

Synthetic teaching models, not measured data. Run render_existing.py to redraw the existing CSVs only.
Check columns, units, conditions and axis limits before replacing data. The reference model does not validate author inputs.
The runner never regenerates data, overwrites output, installs packages or calls an online service.
SOURCE_MANIFEST.json records actual included bytes, without claiming an old GitHub commit contains this package.
