Open k_ion_rate/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
