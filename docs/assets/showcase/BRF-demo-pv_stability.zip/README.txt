Open pv_stability/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
