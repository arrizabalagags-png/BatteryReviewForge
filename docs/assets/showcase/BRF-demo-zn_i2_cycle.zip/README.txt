Open zn_i2_cycle/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
