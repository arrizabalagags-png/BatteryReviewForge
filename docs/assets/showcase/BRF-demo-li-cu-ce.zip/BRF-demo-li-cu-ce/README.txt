这是虚构演示数据，不是实验结果。
把整个文件夹交给 AI 软件，先读取 metadata.json 的单位、测试条件和 source_files，再画图。
输出到新建 brf-output，保留输入文件。

These files are synthetic demonstration data, not experimental results.
This is cycle-by-cycle Li||Cu CE, not an Aurbach protocol. Give both CSV files to BatteryReviewForge.
