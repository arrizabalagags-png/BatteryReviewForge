These files are synthetic demonstration data, not experimental results.
This is cycle-by-cycle Li||Cu CE, not an Aurbach protocol. Give both CSV files to BatteryReviewForge.
