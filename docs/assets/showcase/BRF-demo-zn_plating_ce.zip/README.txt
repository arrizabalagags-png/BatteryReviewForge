Open zn_plating_ce/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
