Open zn_symmetric/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
