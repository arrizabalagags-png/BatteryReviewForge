Open zn_air_power/README.txt, metadata.json and data.csv.
Synthetic teaching data only.
